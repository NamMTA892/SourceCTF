<?php
//flag in flag
//Attempt to upload failed, you have to start over
if (!isset($_GET['shell']) || !isset($_GET['filename'])) {
    highlight_file(__FILE__);
    die();
}
$shell = $_GET['shell'];
if (preg_match('/(on|flag|index|cat|file)/i', $shell)) {
    die("You almost know, try one more time bro !!!");
}
$filename = $_GET['filename'];
if (preg_match("/[^a-z.]/", $filename)) {
    die("You almost know, try one more time bro !!!");
}

file_put_contents($filename, $shell . "\nShout out to MSECCTF 2023 >.<");
?>
